PRINTGUARD AI WEBSITE PACKAGE

Files:
- PrintGuardAI_Website.html : professional project landing page
- PrintGuard_AI_3D_Print_Failure_Predictor.html : linked prediction demo

HOW TO VIEW:
Keep both HTML files in the same folder. Open PrintGuardAI_Website.html in a browser. Click "Launch Prediction Demo" to open the demo.

IMPORTANT:
This package is a static website. To make it available to everyone through a public URL, upload both HTML files to a static hosting service (for example GitHub Pages). The button currently opens the included HTML demo. The separate Python/scikit-learn app requires a Python-capable host and a labelled dataset to train a real model.
